<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tema extends Model
{
     public $timestamps = false;
     protected $table = 'tema';
}
