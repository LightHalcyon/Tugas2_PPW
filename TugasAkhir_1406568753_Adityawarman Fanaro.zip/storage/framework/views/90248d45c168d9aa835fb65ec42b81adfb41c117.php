<!doctype html>
<html lang="<?php echo e(config('app.locale')); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Computer Festival 2017</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
        <script src="https://code.jquery.com/jquery-3.1.1.min.js" integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8=" crossorigin="anonymous"></script>
        <script src="js/registration.js"></script>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            <!--<?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(Auth::check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(url('/login')); ?>">Login</a>
                        <a href="<?php echo e(url('/register')); ?>">Register</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>-->

            <div class="top-right links">
                <a href="<?php echo e(url('/')); ?>">Home</a>
                <a href="<?php echo e(url('/event')); ?>">Event</a>
                <a href="<?php echo e(url('/registration')); ?>">Registration</a>
                <a href="<?php echo e(url('/contactus')); ?>">Contact Us</a>
            </div>

            <div class="content">
                <div class="title m-b-md">
                    Registrasi
                </div>

                <form class="pesan" action="registration/send" method="post">
                    <?php echo e(csrf_field()); ?> 
                    Form Pendaftaran <br> Nama: <input type="Text" name="nama" id="nama"><br> Tema:
                    <select id="tema" name="tema">
                        <option value=""></option>
                        <?php $__currentLoopData = $temas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tema): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tema->id_tema); ?>"><?php echo e($tema->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <br> Status:
                    <select id="status" name="status">
                        <option value="pelajar">Pelajar</option>
                        <option value="profesional">Profesional</option>
                    </select> 
                    <br>Harga Tiket: 
                    <div class="harga-tiket" id="harga" name="harga"></div>
                    <input type="file" name="image" id="image"><br>
                    <input id="kirim" type="submit" value="Send" />
                </form>
                <br>

                <div class="title m-b-md">
                    Daftar Peserta Computer Festival 2017
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>Nama Peserta</th>
                            <th>Tema Acara</th>
                            <th>Status</th>
                            <th>Bukti Pembayaran</th>
                            <th>Total Pembayaran</th>
                        </tr>
                    </thead>
                    <tbody id="pemasukan">
                        <?php $__currentLoopData = $pesertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peserta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $temass; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($peserta->id_tema===$tem->id_tema): ?>
                            <tr>
                                <td><?php echo e($peserta->nama); ?></td>
                                <td><?php echo e($tem->nama); ?></td>
                                <td><?php echo e($peserta->status); ?></td>
                                <td><?php echo e($peserta->bukti_bayar); ?></td>
                                <td><?php echo e(strcmp($peserta->status,'pelajar') ? $tem->harga_tiket : ($tem->harga_tiket)/2); ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </body>
</html>
